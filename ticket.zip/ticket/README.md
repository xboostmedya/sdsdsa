# 🔨 | Başlatma
- İlk öncelikle projeyi indirin. (**git** veya **manuel indirme**)
- Projeyi açıp `config.json` dosyasındaki gerekli bilgileri doldurunuz.
- Daha sonra ana `CMD`'yi açıp şu kodları yazın; `npm install && node .`
- Tebrikler, artık botunuz aktiftir 🎉

# 🎉 | Raven's
- Bir hata veya bir sorunla mı karşılaştın? o zaman [**Raven's**](https://discord.gg/altyapilar) topluluk sunucusuna katıl.

# ⚠ | Uyarı
- Bu projenin alınıp başka bir yerde paylaşılması veya sahiplenmesi katiyen yasaktır, `MIT` lisansı ile korunmaktadır.
